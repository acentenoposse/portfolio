import { Proyecto } from '../modelos/proyecto';

export const PROYECTOS: Proyecto[] = [
  {
    titulo: 'ERP Cairo / Saiko ERP',
    subtitulo: 'Sistema comercial modular con foco en escalabilidad',
    descripcion:
      'Plataforma fullstack orientada a gestión de sucursales, stock, productos, precios, proveedores y operaciones internas. Pensado para crecer a e-commerce y automatizaciones.',
    categoria: 'Proyecto real',
    estado: 'Deployado',
    impacto: 'Arquitectura limpia, ABMC dinámicos, despliegue cloud y base sólida para evolución SaaS.',
    stack: ['Angular 20+', 'TypeScript', 'SCSS', 'ASP.NET Core', 'SQL Server'],
    destacado: ['Arquitectura por features', 'CRUD dinámico', 'Responsive admin UI'],
    demoUrl: 'https://tu-demo-erp.com',
    repoUrl: 'https://github.com/tu-usuario/erp-cairo',
  },
  {
    titulo: 'Falkon Wear E-commerce',
    subtitulo: 'Frontend premium con foco en branding y experiencia de compra',
    descripcion:
      'E-commerce moderno para una marca de ropa urbana masculina. Diseñado con atención fuerte en estética, navegación visual, grillas responsive y componentes reutilizables.',
    categoria: 'Frontend',
    estado: 'En evolución',
    impacto: 'Diseño visual fuerte, experiencia consistente y base sólida para conexión futura con backend.',
    stack: ['Angular 20+', 'Signals', 'SCSS', 'UX/UI', 'Responsive design'],
    destacado: ['Catálogo visual', 'Hero comercial', 'Componentes shared'],
    demoUrl: 'https://tu-demo-falkon.com',
    repoUrl: 'https://github.com/tu-usuario/falkon-wear',
  },
];
